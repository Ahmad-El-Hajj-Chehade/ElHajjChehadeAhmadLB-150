MySQL Aufsetzen
===============
- MySql Server installieren (z.B. XAMPP)
- Datenbank + Benutzer einrichten
  - Datenbank / Schema: affablebean
  - Benutzer: affablebean
  - Passwort: aKtr+wp34Z
  - Wenn ein anderer Benutzer / anderes Passwort verwendet werden soll einfach entsprechend in den application.properties anpassen
- schemaCreation.sql ausführen (Datenbank + Tabellen aufsetzen)
- schemaData.sql ausführen (Testdaten einfügen)
