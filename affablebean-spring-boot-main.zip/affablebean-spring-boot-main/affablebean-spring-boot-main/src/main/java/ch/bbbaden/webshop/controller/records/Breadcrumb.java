package ch.bbbaden.webshop.controller.records;

public record Breadcrumb(String href, String text) {
}
