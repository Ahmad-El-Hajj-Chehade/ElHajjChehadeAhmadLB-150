package ch.bbbaden.webshop.controller.records;

public record Login(String username, String password) {
}
