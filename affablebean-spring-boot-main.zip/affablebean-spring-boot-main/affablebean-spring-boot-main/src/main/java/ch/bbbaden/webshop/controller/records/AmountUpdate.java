package ch.bbbaden.webshop.controller.records;


public record AmountUpdate(short amount) {
}
